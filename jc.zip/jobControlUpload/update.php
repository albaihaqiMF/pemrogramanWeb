<?php

include('db.php');
session_start();
$id_job = $_SESSION['id'];
if (isset($_POST['update'])) {
    $title = $_POST['title'];
    $desc = $_POST['desc'];
    $deadline = $_POST['deadline'];
    if ($title != "" && $desc != "" && $deadline != "") {
            $sql = "UPDATE job_list SET title = '$title', description = '$desc', deadline = '$deadline' WHERE job_list.id = $id_job;";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
                echo "<script>confirm('Data is updated')</script>";
                echo "<script> document.location.href='http://localhost/jobControl/login.php';</script>";
            }
    } else {
        echo "<script>confirm('Data is empty')</script>";
        echo "<script> document.location.href='http://localhost/jobControl/index.php';</script>";
    }
} else {
    echo "Failed Click";
    
    echo "<script> document.location.href='http://localhost/jobControl/index.php';</script>";
}

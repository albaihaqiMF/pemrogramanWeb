<?php

include('db.php');

if (isset($_POST['regis'])) {
    $email = $_POST['email'];
    $name = $_POST['name'];
    $password = md5($_POST['password']);
    if ($email != "" && $name != "" && $password != "") {
        $sql = "SELECT * FROM user WHERE email = '$email';";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();

        if (empty($row)) {
            $sql = "INSERT INTO user (name, email, password) VALUES ('$name', '$email', '$password')";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
                echo "<script>confirm('Register is succesfully')</script>";
                echo "<script> document.location.href='http://localhost/jobControl/login.php';</script>";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "<script>confirm('Email has been used')</script>";
            echo "<script> document.location.href='http://localhost/jobControl/login.php';</script>";
        }
    } else {
        echo "<script>confirm('Data is empty')</script>";
        echo "<script> document.location.href='http://localhost/jobControl/login.php';</script>";
    }
} else {
    echo "Failed Click";
}

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/favicon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="./css/edit.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <title>Update</title>
</head>

<body style="padding: 0;">
    <?php
    include('db.php');
    $id = $_GET['id'];
    $sql = "SELECT * FROM job_list WHERE id='$id';";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
    session_start();
    $_SESSION['id'] = $id;
    ?>
    <div class="edit-form">

        <form action="update.php" method="POST">
            <div class="form-group">
                <label for="">Title</label>
                <input class="form-control" type="text" name="title" value="<?php echo $row['title'] ?>">
            </div>
            <div class="form-group">
                <label for="">Description</label>
                <input class="form-control" type="text" name="desc" value="<?php echo $row['description'] ?>">
            </div>
            <div class="form-group">
                <label for="">Deadline</label>
                <input class="form-control" type="date" name="deadline" value="<?php echo $row['deadline'] ?>">
            </div>
            <div class="btn-group">
                <button class="btn btn-primary" name="update">UPDATE</button>
                <button class="btn btn-success" href="index.php">CANCEL</button>
            </div>
        </form>
    </div>
</body>

</html>
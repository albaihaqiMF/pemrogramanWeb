<?php
session_start();
if (isset($_SESSION['login'])) {
    $data = $_SESSION['login'];
} else {
    header("location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="images/favicon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="./css/index.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <title>Job Control</title>
</head>

<body>
    <div class="slogan">
        <p style="margin: 0;">Control & Monitoring your job</p>
    </div>
    <div class="hello sticky-top">
        <h1 style="color: white;">Hello <?php echo $data['name']; ?></h1>
    </div>
    <div class="adition">
        <div class="header-btn">
            <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Add</button>

            <a onclick="logoutConfirm()" class="btn btn-danger btn-lg">Logout</a>
        </div>
        <script>
            function logoutConfirm() {
                var cond = confirm("Are you sure want to logout?");
                if (cond == true) {
                    document.location.href = "logout.php";
                }
            }
        </script>


        <div class="modal" id="myModal" role="dialog">
            <div class="modal-dialog">

                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Add Your Job</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form action="addition.php" method="POST">
                            <div class="form-group">
                                <label for="">Title</label>
                                <input class="form-control" type="text" name="title" id="" placeholder="Job Title">
                            </div>
                            <div class="form-group">
                                <label for="">Description</label>
                                <input class="form-control" type="text" name="desc" id="" placeholder="Describe your job">
                            </div>
                            <div class="form-group">
                                <label for="">Deadline</label>
                                <input class="form-control" type="date" name="deadline" id="">
                            </div>
                            <div class="btn-group">
                                <button class="btn btn-primary" name="add">SUBMIT</button>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="job-list" class="container">
        <!-- job component -->
        <?php
        include('db.php');
        $user_id = $data['id'];
        $sql = "SELECT * FROM job_list WHERE user_id='$user_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
        ?>
                <div class="job-detail">
                    <div class="job-desc">
                        <h4><?php echo $row['title'] ?></h4>
                        <p><?php echo $row['description'] ?></p>
                        <p class="btn btn-primary"><?php echo $row['deadline'] ?></p>
                    </div>
                    <?php
                    if ($row['status'] == '1') {

                    ?>
                        <div class="action">
                            <a href="finish.php?id=<?php echo $row['id'] ?>" class="btn icon btn-primary" title="Done"><i class="glyphicon glyphicon-ok"></i></a>
                            <a href="delete.php?id=<?php echo $row['id'] ?>" class="btn icon btn-danger" title="Delete"><i class="glyphicon glyphicon-remove"></i></a>
                            <button href="edit.php?id=<?php echo $row['id'] ?>" class="btn icon btn-success" title="Update" data-toggle="modal" data-target="#editModal"><i class="glyphicon glyphicon-pencil"></i></button>
                        </div>
                    <?php
                    } else {
                    ?>
                        <div class="action">
                            <h4 class="btn btn-success">DONE</h4>
                        </div>
                    <?php
                    }
                    ?>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="editModal" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h4 class="modal-title">Add Your Job</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <p>Hellooo</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>

                        </div>
                    </div>
                </div>
        <?php
            }
        } else {
            echo "<center><h1>EMPTY</h1></center>";
            echo "<center><p>Create new Note</p></center>";
        }
        ?>
    </div>
    <div class="footer">
        <p>muhammad.fahmi1009@students.unila.ac.id</p>
        <p>copyright 2020</p>
    </div>
</body>

</html>
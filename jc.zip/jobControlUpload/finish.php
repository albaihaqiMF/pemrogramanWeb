<?php
include('db.php');

$id = $_GET['id'];
$sql = "UPDATE job_list SET status='0' WHERE job_list.id = $id;";

$result = $conn->query($sql);


echo "<script>document.location.href='index.php'</script>";
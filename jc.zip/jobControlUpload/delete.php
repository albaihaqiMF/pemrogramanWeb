<?php
include('db.php');
$id = $_GET['id'];

$sql = "DELETE FROM job_list WHERE id='$id';";
$result = $conn->query($sql);

echo "<script>document.location.href='index.php'</script>";
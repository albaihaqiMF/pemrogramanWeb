<?php

include('db.php');
session_start();
$data = $_SESSION['login'];
$user_id = $data['id'];

if (isset($_POST['add'])) {
    $title = $_POST['title'];
    $desc = $_POST['desc'];
    $deadline = $_POST['deadline'];
    if ($title != "" && $desc != "" && $deadline != "") {
            $sql = "INSERT INTO job_list (user_id, description, title, deadline, status) VALUES ($user_id,'$desc', '$title', '$deadline', '1')";

            if ($conn->query($sql) === TRUE) {
                echo "New record created successfully";
                echo "<script>confirm('Addition is succesfully')</script>";
                echo "<script> document.location.href='http://localhost/jobControl/login.php';</script>";
            }
    } else {
        echo "<script>confirm('Data is empty')</script>";
        echo "<script> document.location.href='http://localhost/jobControl/index.php';</script>";
    }
} else {
    echo "Failed Click";
}
